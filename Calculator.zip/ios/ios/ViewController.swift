//
//  ViewController.swift
//  ios
//
//  Created by Furkan Baris Duyar on 6.11.2018.
//  Copyright © 2018 Furkan Baris Duyar. All rights reserved.
//

import UIKit

var resultForHistory:String = "";
var history = [String]()

class ViewController: UIViewController {

    var numberOnScreen:Double=0
    var saved:Double=0
    var result:Double=0
    var dot:Bool=false
    var add:Bool=false
    var multiply:Bool=false
    var divide:Bool=false
    var subs:Bool=false
    var newEntry:Bool=false
    var negative:Bool=false
    var sqart:Bool=false
    var mode:Bool=false
    var percent:Bool=false
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBAction func numbers(_ sender: UIButton) {
        
        if(newEntry)
        {
            resultLabel.text=""
            newEntry=false
        }
        
        resultLabel.text! += String(sender.tag-1)
        resultForHistory += String(sender.tag-1)
        
    }
    
    
    @IBAction func operationButtons(_ sender: UIButton) {
        
        if(resultLabel.text == "")
        {
            resultLabel.text="0"
        }
        
        if sender.tag != 17
        {
            dot = false
        }
        else
        {
            dot = true
        }
        
        if(result==0 && !dot)
        {
            numberOnScreen=Double(resultLabel.text!)!
            result=numberOnScreen
        }
        else if result != 0 && !dot
        {
            numberOnScreen=Double(resultLabel.text!)!
        }
        
        //current expression
        if mode
        {
            resultForHistory += ") "
            result=result.truncatingRemainder(dividingBy: numberOnScreen)
            result+=saved
            numberOnScreen = 0
            mode=false
            resultLabel.text! = String(result)
            //resultForHistory += String(result)
            
            if(sender.tag==16)
            {
                resultForHistory += " = " + String(result)
                history.append(resultForHistory)
                resultForHistory = ""
            }
            
            //history.append(resultForHistory)
            //resultForHistory = ""
        }
        else if multiply
        {
            result*=numberOnScreen
            multiply=false
            
            if sender.tag==14 || sender.tag==15 || sender.tag==16
            {
                result+=saved
                
                if(sender.tag==16)
                {
                    resultForHistory += " = " + String(result)
                    history.append(resultForHistory)
                    resultForHistory = ""
                }
                
                saved=0
                numberOnScreen=0
            }
            
            resultLabel.text! = String(result)
        }
        else if divide
        {
            result/=numberOnScreen
            divide=false
            
            if sender.tag==14 || sender.tag==15 || sender.tag==16
            {
                result+=saved
                
                if(sender.tag==16)
                {
                    resultForHistory += " = " + String(result)
                    history.append(resultForHistory)
                    resultForHistory = ""
                }
                
                saved=0
                numberOnScreen=0
            }
            
            resultLabel.text! = String(result)
        }
        else if add
        {
            if sender.tag==14 || sender.tag==15 || sender.tag==16
            {
                add=false
                result+=numberOnScreen
                result+=saved
                
                if(sender.tag==16)
                {
                    resultForHistory += " = " + String(result)
                    history.append(resultForHistory)
                    resultForHistory = ""
                }
                
                saved=0
                numberOnScreen=0
                resultLabel.text! = String(result)
            }
            else if sender.tag==21
            {
                mode=true
                saved=result
                result=numberOnScreen
                numberOnScreen=0
                
            }
            else if sender.tag==13 //multiply
            {
                multiply=true
                saved=result
                result=numberOnScreen
                numberOnScreen=0
                
                resultForHistory += " "
            }
            else if sender.tag==12 //divide
            {
                divide=true
                saved=result
                result=numberOnScreen
                numberOnScreen=0
            }
        }
        else if subs
        {
            if sender.tag==14 || sender.tag==15 || sender.tag==16
            {
                //incele
                subs=false
                result-=numberOnScreen
                result+=saved
                
                if(sender.tag==16)
                {
                    resultForHistory += " = " + String(result)
                    history.append(resultForHistory)
                    resultForHistory = ""
                }
                
                saved=0
                numberOnScreen=0
                resultLabel.text! = String(result)
            }
            else if sender.tag==21
            {
                mode=true
                saved=result
                result=numberOnScreen*(-1)
                numberOnScreen=0
                
            }
            else if sender.tag==13//multiply
            {
                multiply=true
                saved=result
                result=numberOnScreen*(-1)
                numberOnScreen=0
            }
            else if sender.tag==12 //divide
            {
                divide=true
                saved=result
                result=numberOnScreen*(-1) // -1 ile çarpmayı unutma
                numberOnScreen=0
            }
        }
        
        //next expressions
        if sender.tag==15 //add
        {
            add=true
            
            resultForHistory += " + "
        }
        else if sender.tag==13 //multiply
        {
            multiply=true
            
            resultForHistory += " * "
        }
        else if sender.tag==12 //divide
        {
            divide=true
            
            resultForHistory += " / "
        }
       
        else if sender.tag==14 //subs
        {
            subs=true
            
            resultForHistory += " - "
        }
        else if sender.tag==19 //yüzde
        {
            result+=saved
            saved=0
            result=result/100
            resultLabel.text=String(result)
            
            resultForHistory += "%"
        }
        else if sender.tag==11
        {
            resultLabel.text! = "0"
            numberOnScreen=0
            saved=0
            result=0
            dot = false
            add=false
            multiply=false
            divide=false
            subs=false
            newEntry=false
            negative=false
            sqart=false
            mode=false
            percent=false
            resultForHistory = ""
        }
            
        else if sender.tag==20 //sqrt
        {
            
            resultForHistory += "Kök"
            
            numberOnScreen=sqrt(numberOnScreen)
            result=numberOnScreen
            resultLabel.text!=String(result)
            
            //history.append(resultForHistory)
            //resultForHistory = ""
        }
       
        else if sender.tag==21 //mod
        {
            mode=true
            
            resultForHistory += "mod("
        }
        newEntry=true
        negative=false
        
        if sender.tag==17
        {
           newEntry=false
           resultLabel.text! += "."
            
           resultForHistory += "."
            
        }

        
    }
    
    
    @IBAction func historyButton(_ sender: UIButton) {
        resultLabel.text! = "0"
        numberOnScreen=0
        saved=0
        result=0
        dot = false
        add=false
        multiply=false
        divide=false
        subs=false
        newEntry=false
        negative=false
        sqart=false
        mode=false
        percent=false
        resultForHistory = ""
        performSegue(withIdentifier: "segue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

