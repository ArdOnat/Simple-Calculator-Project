//
//  ViewController2.swift
//  ios
//
//  Created by Furkan Baris Duyar on 6.11.2018.
//  Copyright © 2018 Furkan Baris Duyar. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    
    @IBOutlet weak var historyTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func clearButton(_ sender: UIButton) {
        historyTextView.text = ""
        history = [String]()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        var i = 0;
        
        while i != history.count {
            historyTextView.text += String(i + 1) + ") " + history[i] + "\n\n"
            i = i + 1
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
